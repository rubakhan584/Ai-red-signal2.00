# Red Signal AI — Android Studio Project

এই প্রজেক্টে আছে:
- Jetpack Compose-ভিত্তিক Android UI
- Red/Black Neon থিম
- Gemini API key সেটিংস (key ফোনে encrypted preferences-এ রাখা হয়)
- API connection test
- Basic text chat, loading state, retry-friendly error message
- আলাদা Gemini service layer

## Build করার ধাপ
1. ZIP ফাইলটি Extract করো।
2. Android Studio-তে `RedSignalAI` ফোল্ডারটি Open করো।
3. Gradle Sync শেষ হতে দাও। JDK 17 ব্যবহার করো।
4. Run করতে ফোনে USB debugging চালু করে ফোন connect করো, অথবা Android emulator চালাও।
5. APK বানাতে: **Build > Build Bundle(s) / APK(s) > Build APK(s)**।
6. APK সাধারণত `app/build/outputs/apk/debug/app-debug.apk`-এ থাকবে।

## Gemini API key
1. Google AI Studio থেকে নিজের Gemini API key তৈরি করো।
2. অ্যাপ খুলে **Settings**-এ যাও।
3. API key লিখে Save করো, তারপর Test Connection চাপো।
4. Chat screen-এ ফিরে প্রশ্ন পাঠাও।

## গুরুত্বপূর্ণ নিরাপত্তা
- নিজের API key কাউকে পাঠাবে না বা public repository-তে রাখবে না।
- ফোনে encrypted storage থাকলেও rooted/compromised device-এ সম্পূর্ণ নিরাপত্তার নিশ্চয়তা নেই।
- Public app প্রকাশ করলে নিজের server/backend proxy ব্যবহার করা ভালো, যাতে API usage সীমা ও অপব্যবহার নিয়ন্ত্রণ করা যায়।
- API availability, quota, billing এবং model access Google-এর account ও policy অনুযায়ী বদলাতে পারে।
- এই project এখানে build করে যাচাই করা হয়নি; Android Studio-তে Gradle Sync/Build করে errors থাকলে সেগুলো ঠিক করতে হবে।
