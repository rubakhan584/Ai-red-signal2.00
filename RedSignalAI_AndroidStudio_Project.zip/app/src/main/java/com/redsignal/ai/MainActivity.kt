package com.redsignal.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

private val Bg = Color(0xFF08090D)
private val Panel = Color(0xFF151821)
private val Red = Color(0xFFFF253A)
private val White = Color(0xFFF5F6FA)
private val Muted = Color(0xFF9CA3AF)

class MainActivity : ComponentActivity() {
    private lateinit var keyStore: ApiKeyStore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        keyStore = ApiKeyStore(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Red, background = Bg, surface = Panel,
                onPrimary = White, onBackground = White, onSurface = White
            )) {
                var screen by remember { mutableStateOf("chat") }
                var apiKey by remember { mutableStateOf(keyStore.getKey()) }
                var messages by remember { mutableStateOf(listOf<ChatMessage>()) }
                var input by remember { mutableStateOf("") }
                var busy by remember { mutableStateOf(false) }
                var status by remember { mutableStateOf("") }
                var showKey by remember { mutableStateOf(false) }

                Surface(Modifier.fillMaxSize(), color = Bg) {
                    if (screen == "settings") {
                        Column(
                            Modifier.fillMaxSize().background(
                                Brush.verticalGradient(listOf(Color(0xFF1B0B10), Bg))
                            ).padding(20.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(onClick = { screen = "chat"; status = "" }) {
                                    Icon(Icons.Default.ArrowBack, "Back", tint = White)
                                }
                                Text("Gemini API Settings", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                            }
                            Text("Add your own Gemini API key", color = Muted)
                            OutlinedTextField(
                                value = apiKey,
                                onValueChange = { apiKey = it; status = "" },
                                modifier = Modifier.fillMaxWidth(),
                                label = { Text("Gemini API Key") },
                                singleLine = true,
                                visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                                trailingIcon = {
                                    IconButton(onClick = { showKey = !showKey }) {
                                        Icon(if (showKey) Icons.Default.VisibilityOff else Icons.Default.Visibility, "Show/hide key")
                                    }
                                },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = Red, unfocusedBorderColor = Color.DarkGray,
                                    focusedLabelColor = Red, cursorColor = Red
                                )
                            )
                            Button(
                                onClick = {
                                    keyStore.saveKey(apiKey.trim())
                                    apiKey = apiKey.trim()
                                    status = if (apiKey.isBlank()) "API key removed." else "API key saved on this device."
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = Red)
                            ) { Text("Save API Key") }
                            OutlinedButton(
                                onClick = {
                                    if (apiKey.isBlank()) status = "Enter an API key first."
                                    else {
                                        status = "Testing connection…"
                                        lifecycleScope.launch {
                                            status = GeminiService.test(apiKey.trim())
                                        }
                                    }
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("Test API Connection") }
                            if (status.isNotBlank()) Text(status, color = if (status.contains("success", true) || status.contains("saved", true)) Color(0xFF62E6A7) else Red)
                            Text(
                                "Keep your key private. API usage limits or billing may apply. For a public app, use a secure backend.",
                                color = Muted, fontSize = 13.sp
                            )
                            Spacer(Modifier.weight(1f))
                            Text("RED SIGNAL AI • v1.0", color = Muted, fontSize = 12.sp)
                        }
                    } else {
                        Column(
                            Modifier.fillMaxSize().background(
                                Brush.verticalGradient(listOf(Color(0xFF19080D), Bg, Bg))
                            ).padding(16.dp)
                        ) {
                            Row(
                                Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    Modifier.size(44.dp).background(
                                        Brush.linearGradient(listOf(Red, Color(0xFF8B0014))),
                                        CircleShape
                                    ),
                                    contentAlignment = Alignment.Center
                                ) { Text("R", fontWeight = FontWeight.Black, fontSize = 24.sp) }
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text("Red Signal AI", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                                    Text("Gemini Chat Assistant", color = Muted, fontSize = 12.sp)
                                }
                                IconButton(onClick = { screen = "settings"; status = "" }) {
                                    Icon(Icons.Default.Settings, "Settings", tint = Red)
                                }
                            }
                            Spacer(Modifier.height(18.dp))
                            if (messages.isEmpty()) {
                                Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("✦", color = Red, fontSize = 58.sp)
                                        Text("Welcome to Red Signal", fontSize = 23.sp, fontWeight = FontWeight.Bold)
                                        Spacer(Modifier.height(8.dp))
                                        Text("Ask anything. Get smarter.", color = Muted)
                                        Spacer(Modifier.height(18.dp))
                                        Text("Open Settings to add your Gemini API key.", color = Muted, fontSize = 13.sp)
                                    }
                                }
                            } else {
                                LazyColumn(
                                    Modifier.weight(1f).fillMaxWidth(),
                                    verticalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    items(messages) { message ->
                                        Row(
                                            Modifier.fillMaxWidth(),
                                            horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start
                                        ) {
                                            Box(
                                                Modifier.widthIn(max = 310.dp)
                                                    .background(
                                                        if (message.fromUser) Color(0xFF641923) else Panel,
                                                        RoundedCornerShape(18.dp)
                                                    ).padding(14.dp)
                                            ) { Text(message.text, color = White, lineHeight = 21.sp) }
                                        }
                                    }
                                    if (busy) item {
                                        Text("Gemini is thinking…", color = Red, modifier = Modifier.padding(8.dp))
                                    }
                                }
                            }
                            if (status.isNotBlank()) {
                                Text(status, color = if (status.contains("error", true) || status.contains("enter", true)) Red else Muted, fontSize = 12.sp)
                                Spacer(Modifier.height(6.dp))
                            }
                            Row(
                                Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(28.dp)).padding(6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                TextField(
                                    value = input,
                                    onValueChange = { input = it },
                                    modifier = Modifier.weight(1f),
                                    placeholder = { Text("Message Red Signal AI…", color = Muted) },
                                    maxLines = 4,
                                    colors = TextFieldDefaults.colors(
                                        focusedContainerColor = Color.Transparent,
                                        unfocusedContainerColor = Color.Transparent,
                                        focusedIndicatorColor = Color.Transparent,
                                        unfocusedIndicatorColor = Color.Transparent,
                                        cursorColor = Red
                                    )
                                )
                                IconButton(
                                    enabled = !busy && input.isNotBlank(),
                                    onClick = {
                                        val question = input.trim()
                                        if (apiKey.isBlank()) {
                                            status = "Open Settings and add your Gemini API key."
                                        } else if (question.isNotBlank()) {
                                            input = ""
                                            messages = messages + ChatMessage(question, true)
                                            busy = true
                                            status = ""
                                            lifecycleScope.launch {
                                                val answer = GeminiService.ask(apiKey, question)
                                                messages = messages + ChatMessage(answer, false)
                                                busy = false
                                                if (answer.startsWith("Error:")) status = "Request failed. Check key, internet, quota, and model access."
                                            }
                                        }
                                    },
                                    modifier = Modifier.size(46.dp).background(Red, CircleShape)
                                ) {
                                    Icon(Icons.Default.Send, "Send", tint = White)
                                }
                            }
                            Spacer(Modifier.height(6.dp))
                        }
                    }
                }
            }
        }
    }
}

data class ChatMessage(val text: String, val fromUser: Boolean)
