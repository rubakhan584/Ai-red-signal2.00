package com.redsignal.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

object GeminiService {
    // If Google changes available models, update this model name in one place.
    private const val MODEL = "gemini-2.5-flash"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/"
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .callTimeout(70, TimeUnit.SECONDS)
        .build()
    private val jsonType = "application/json; charset=utf-8".toMediaType()

    suspend fun ask(apiKey: String, prompt: String): String = withContext(Dispatchers.IO) {
        try {
            val content = JSONObject()
                .put("parts", JSONArray().put(JSONObject().put("text", prompt)))
            val body = JSONObject().put("contents", JSONArray().put(content))
                .toString().toRequestBody(jsonType)
            val request = Request.Builder()
                .url("${BASE_URL}${MODEL}:generateContent?key=${apiKey.trim()}")
                .post(body)
                .build()
            client.newCall(request).execute().use { response ->
                val raw = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val detail = try { JSONObject(raw).optJSONObject("error")?.optString("message") } catch (_: Exception) { null }
                    "Error: ${detail?.takeIf { it.isNotBlank() } ?: "HTTP ${response.code}"}"
                } else {
                    val root = JSONObject(raw)
                    val candidates = root.optJSONArray("candidates")
                    val parts = candidates?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                    val text = parts?.let { arr ->
                        (0 until arr.length()).mapNotNull { i ->
                            arr.optJSONObject(i)?.optString("text")?.takeIf { it.isNotBlank() }
                        }.joinToString("\n")
                    }.orEmpty()
                    text.ifBlank { "Error: Gemini returned an empty response." }
                }
            }
        } catch (e: IOException) {
            "Error: Network connection failed. Check your internet and try again."
        } catch (e: Exception) {
            "Error: ${e.message ?: "Unexpected error"}"
        }
    }

    suspend fun test(apiKey: String): String = withContext(Dispatchers.IO) {
        try {
            val body = JSONObject()
                .put("contents", JSONArray().put(
                    JSONObject().put("parts", JSONArray().put(JSONObject().put("text", "Reply with OK")))
                )).toString().toRequestBody(jsonType)
            val request = Request.Builder()
                .url("${BASE_URL}${MODEL}:generateContent?key=${apiKey.trim()}")
                .post(body)
                .build()
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) "Connection success! Gemini API is responding."
                else {
                    val raw = response.body?.string().orEmpty()
                    val detail = try { JSONObject(raw).optJSONObject("error")?.optString("message") } catch (_: Exception) { null }
                    "Connection failed: ${detail?.takeIf { it.isNotBlank() } ?: "HTTP ${response.code}"}"
                }
            }
        } catch (_: Exception) {
            "Connection failed: Check internet and API key."
        }
    }
}
